#include "StdAfx.h"
#include "cuenta1.h"
#include <iostream>

cuenta1::cuenta1(void)
{
	saldo=0.0;
}
cuenta1::~cuenta1(void)
{
}

cuenta1::cuenta1(string nom, string cuen, double sal, double tipoDeInter)
{
	asignar_Nombre(nom);
	asignar_Cuenta(cuen);
	
	//asignar_Interes(tipoInter);
}

void cuenta1::asignar_Nombre(string nom){
	if(nom.length()==0)
	{
		cout<<"Error, no se ha asignado un nombre"<<endl;
		return;
	}
	nombre = nom;

}
	
void cuenta1::asignar_Cuenta(string cue){
	cuenta = cue;
}

string cuenta1::obtener_Nombre(){
	return nombre;
}

string cuenta1::obtener_Cuenta(){
		return cuenta;
	}

double cuenta1::obtener_Interes(){
		return tipoDeInteres;
	}

double cuenta1::estado(){
		return saldo;
	}

void cuenta1::asignar_Interes(double interes){
	tipoDeInteres = interes;
	}

void cuenta1::reintegro(double cantidad){
		if((saldo-cantidad)<0)
		{
			cout<<"Error se qued� yesca"<<endl;
			return;
		}
		saldo=saldo-cantidad;

	}

void cuenta1::ingreso(double cantidad){
		if (cantidad<0)
		{
			cout<<"Error: Cantidad menor a 0"<<endl; 
			return;
		}
		else 
		{
			saldo=saldo+cantidad;
		}

		

	}



