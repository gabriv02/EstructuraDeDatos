#pragma once
#include <iostream>
#include <string>
using namespace std;



class cuenta1
{
private:
	
	double tipoDeInteres; 
	double saldo; 
	string cuenta;
	string nombre;

public:
	cuenta1(void);
	cuenta1 (string nom, string cuen, double sal, double tipoDeInter);
	~cuenta1(void);
	void asignar_Nombre(string nom); 
	void asignar_Cuenta(string cue);
	string obtener_Nombre();
	string obtener_Cuenta();
	double obtener_Interes();
	double estado();
	void asignar_Interes(double interes);
	void reintegro(double cantidad);
	void ingreso(double cantidad);
};

