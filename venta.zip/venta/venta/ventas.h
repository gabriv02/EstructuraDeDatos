#pragma once
ref class ventas
{
private:
	int cantidad;
	float precio;
	float total;
public:                       
	ventas(void);
	int Get_cantidad();
	float Get_precio();
	float Get_total();
	void Set_cantidad(int c);
	void Set_precio(float p);
	void Set_total(float t);
	float calcular();
};


