#include "StdAfx.h"
#include "ventas.h"


ventas::ventas(void)
{
}
int ventas::Get_cantidad()
{
	return cantidad;
}
float ventas::Get_precio()
{
	return precio;
}
float ventas::Get_total()
{
	return total;
}
void ventas::Set_cantidad(int c)
{
	cantidad=c;
}
void ventas::Set_precio(float p)
{
	precio=p;
}
void ventas::Set_total(float t)
{
	total=t;
}
float ventas::calcular()
{
	total=cantidad*precio;
	return total;
}


