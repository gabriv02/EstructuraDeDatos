#include "StdAfx.h"
#include "circulo.h"


circulo::circulo(void)
{
}
float circulo::Get_radio()
{
	return radio;
}
double circulo::Get_perimetro()
{
	return perimetro;
}
void circulo::Set_radio(float r)
{
	radio=r;
}
void circulo::Set_perimetro(double p)
{
	perimetro=p;
}
double circulo::calcular()
{
	perimetro=2*3.1416*radio;
	return perimetro;
}

