#include "StdAfx.h"
#include "Triangulos.h"


Triangulos::Triangulos(void)
{
}
int Triangulos::Get_base()
{
	return base;
}
int Triangulos::Get_altura()
{
	return altura;
}
void Triangulos::Set_base(int b)
{
	base=b;
}
void Triangulos::Set_altura(int h)
{
	altura=h;
}
int Triangulos::Get_area()
{
	return area;
}
void Triangulos::Set_area(int a){
	area=a;
}
int Triangulos::calcular()
{
	area=(base*altura)/2;
	return area;
}