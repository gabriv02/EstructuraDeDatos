#pragma once
#include "Triangulos.h"
#include <iostream>
#include <msclr\marshal_cppstd.h>

namespace TRIANGULO {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblBase;
	protected: 
	private: System::Windows::Forms::Label^  lblAltura;
	private: System::Windows::Forms::Label^  lblArea;
	private: System::Windows::Forms::Button^  btnCalcular;
	private: System::Windows::Forms::TextBox^  txtBase;
	private: System::Windows::Forms::TextBox^  txtAltura;
	private: System::Windows::Forms::TextBox^  txtArea;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblBase = (gcnew System::Windows::Forms::Label());
			this->lblAltura = (gcnew System::Windows::Forms::Label());
			this->lblArea = (gcnew System::Windows::Forms::Label());
			this->btnCalcular = (gcnew System::Windows::Forms::Button());
			this->txtBase = (gcnew System::Windows::Forms::TextBox());
			this->txtAltura = (gcnew System::Windows::Forms::TextBox());
			this->txtArea = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// lblBase
			// 
			this->lblBase->AutoSize = true;
			this->lblBase->Location = System::Drawing::Point(26, 27);
			this->lblBase->Name = L"lblBase";
			this->lblBase->Size = System::Drawing::Size(40, 17);
			this->lblBase->TabIndex = 0;
			this->lblBase->Text = L"Base";
			this->lblBase->Click += gcnew System::EventHandler(this, &Form1::lblBase_Click);
			// 
			// lblAltura
			// 
			this->lblAltura->AutoSize = true;
			this->lblAltura->Location = System::Drawing::Point(26, 70);
			this->lblAltura->Name = L"lblAltura";
			this->lblAltura->Size = System::Drawing::Size(45, 17);
			this->lblAltura->TabIndex = 1;
			this->lblAltura->Text = L"Altura";
			this->lblAltura->Click += gcnew System::EventHandler(this, &Form1::lblAltura_Click);
			// 
			// lblArea
			// 
			this->lblArea->AutoSize = true;
			this->lblArea->Location = System::Drawing::Point(26, 164);
			this->lblArea->Name = L"lblArea";
			this->lblArea->Size = System::Drawing::Size(38, 17);
			this->lblArea->TabIndex = 2;
			this->lblArea->Text = L"Area";
			// 
			// btnCalcular
			// 
			this->btnCalcular->Location = System::Drawing::Point(96, 112);
			this->btnCalcular->Name = L"btnCalcular";
			this->btnCalcular->Size = System::Drawing::Size(75, 23);
			this->btnCalcular->TabIndex = 3;
			this->btnCalcular->Text = L"Calcular";
			this->btnCalcular->UseVisualStyleBackColor = true;
			this->btnCalcular->Click += gcnew System::EventHandler(this, &Form1::btnCalcular_Click);
			// 
			// txtBase
			// 
			this->txtBase->Location = System::Drawing::Point(185, 27);
			this->txtBase->Name = L"txtBase";
			this->txtBase->Size = System::Drawing::Size(100, 22);
			this->txtBase->TabIndex = 4;
			this->txtBase->TextChanged += gcnew System::EventHandler(this, &Form1::txtBase_TextChanged);
			// 
			// txtAltura
			// 
			this->txtAltura->Location = System::Drawing::Point(185, 65);
			this->txtAltura->Name = L"txtAltura";
			this->txtAltura->Size = System::Drawing::Size(100, 22);
			this->txtAltura->TabIndex = 5;
			this->txtAltura->TextChanged += gcnew System::EventHandler(this, &Form1::txtAltura_TextChanged);
			// 
			// txtArea
			// 
			this->txtArea->Location = System::Drawing::Point(185, 161);
			this->txtArea->Name = L"txtArea";
			this->txtArea->Size = System::Drawing::Size(100, 22);
			this->txtArea->TabIndex = 6;
			this->txtArea->TextChanged += gcnew System::EventHandler(this, &Form1::txtArea_TextChanged);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(320, 222);
			this->Controls->Add(this->txtArea);
			this->Controls->Add(this->txtAltura);
			this->Controls->Add(this->txtBase);
			this->Controls->Add(this->btnCalcular);
			this->Controls->Add(this->lblArea);
			this->Controls->Add(this->lblAltura);
			this->Controls->Add(this->lblBase);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

private: System::Void lblBase_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void lblAltura_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void btnCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
			 Triangulos triangulito;
			 triangulito.Set_base(System::Convert::ToInt32(txtBase-> Text));
			 triangulito.Set_altura(System::Convert::ToInt32(txtAltura-> Text));
			 int areaT;
			 areaT = triangulito.calcular();
			 txtArea -> Text = System::Convert::ToString(areaT);
		 }

private: System::Void txtArea_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void txtAltura_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void txtBase_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}

