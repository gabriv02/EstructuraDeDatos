#pragma once
ref class Triangulos
{
private:
	int base;
	int altura;
	int area;
public:
	Triangulos(void);
	int Get_base();
	int Get_altura();
	void Set_base(int b);
	void Set_altura(int h);
	int Get_area();
	void Set_area(int a);
	int calcular();
};

