#include "stdafx.h"
#include "cola.h"


using std::cout;

cola::cola() {
	raiz = NULL;
	primero = NULL;
}

void cola::insertar(int x) {
	Nodo* nuevo;
	nuevo = new Nodo();
	nuevo->info = x;
	if (raiz == NULL) {
		raiz = nuevo;
		nuevo->sig = NULL;
		primero = nuevo;
	} else {
		nuevo->sig = NULL;
		raiz->sig = nuevo;
		raiz = nuevo;
	}
}

int cola::extraer() {
	if (primero != NULL) {
		int informacion = primero->info;
		Nodo* borrar = primero;
		primero = primero->sig;
		delete borrar;
		return informacion;

	} else {
		return -1;
	}
}


void cola::insertarSoloMenores(int x) {
	if (x < raiz->info) {
		Nodo* nuevo;
		nuevo = new Nodo();
		nuevo->info = x;
		if (raiz == NULL) {
			raiz = nuevo;
			nuevo->sig = NULL;
			primero = nuevo;
		} else {
			nuevo->sig = NULL;
			raiz->sig = nuevo;
			raiz = nuevo;
		}
	}
}


void cola::imprimir() {
	Nodo* next = primero;
	cout << "Elementos de la lista: \n";
	while (next != NULL) {
		cout << "[" << next->info << "] -> ";
		next = next->sig;
	}

}

cola::~cola() {
	Nodo* next = raiz;
	Nodo* borrar;
	while (next != NULL); {
		borrar = next;
		next = next->sig;
		delete borrar;
	}
}
