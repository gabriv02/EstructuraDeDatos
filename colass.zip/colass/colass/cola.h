#pragma once
#include <iostream>


class cola {

private:
	class Nodo {
	public:
		int info; //variables que te de la gana
		Nodo* sig;
	};
	Nodo* raiz;
	Nodo* primero;
	
public:
	cola();
	~cola();

	void insertar(int x);
	int extraer();
	void imprimir();
	void insertarSoloMenores(int x);
};

