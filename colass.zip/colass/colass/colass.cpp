// colass.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "cola.h"

#include <iostream>

using std::cout;

int main()
{
	cola* colarica = new cola();
	colarica->insertar(13414);
	colarica->insertar(13415);
	colarica->insertar(13414);
	colarica->insertar(13420);
	colarica->insertarSoloMenores(5);
	colarica->insertarSoloMenores(13421);


	colarica->imprimir();
	

	system("pause");

    return 0;
}