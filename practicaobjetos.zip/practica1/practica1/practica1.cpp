// practica1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "ejemplo1.h"
#include <iostream>

using namespace std;

//ejemplo1 pollito(2,2,true,"pollito");
//ejemplo1 pato(0,0,true,"pato");
//ejemplo1 cerdo;
//ejemplo1 tractor("tractor",true);
//ejemplo1 molino("molino",true);
ejemplo1 granja[5];


int _tmain(int argc, _TCHAR* argv[])
{
	granja[0] =  ejemplo1("pollito",2,2,true);
	granja [1] =  ejemplo1("pato",0,0,true);
	granja [2] =  ejemplo1("cerdo",0,0,false);
	granja [3] =  ejemplo1("tractor",true);
	granja [4] =  ejemplo1("molino",true);

	for(int i=0;i<=4;i++){
		granja[i].imprimir();
	}
	//pollito.imprimir();
	//pato.imprimir();
	//cerdo.imprimir();
	//tractor.imprimir();
	//molino.imprimir();
	ejemplo1 *dir_polli;
	ejemplo1 *ubi_polli;
	dir_polli = &granja[0];
	
	cout << endl << endl << dir_polli->num_patas << endl;



	system("pause");
	return 0;
}

void algo(ejemplo1 &grnaja){
		//hace algo
}
