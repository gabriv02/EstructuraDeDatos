#include "StdAfx.h"
#include "ejemplo1.h"

ejemplo1::ejemplo1(void)
{
	num_patas = 0;
	num_cabeza = 0;
	hambre = false;
	nombre = "cerdo";
	maquina = false;

}

ejemplo1::ejemplo1(string _nombre,int _patas, int _cabeza, bool _hambre){
		nombre = _nombre;
		num_patas = _patas;
		num_cabeza = _cabeza;
		hambre = _hambre;
}
ejemplo1::ejemplo1(string _nombre, bool _maquina){
	nombre = _nombre;
	maquina = _maquina;
}

ejemplo1::~ejemplo1(void)
{
}

void ejemplo1::set_cabeza(int num_cab){
	num_cabeza = num_cab;

}

int ejemplo1::get_cabeza(){
	return num_cabeza;
}

void ejemplo1::imprimir(){
	if(maquina==true){
		cout << "hay " << nombre <<endl;
	}else {
		cout<<nombre<<" tiene "<<num_patas<<" patas, "<<num_cabeza<<" cabezas y "<< hambre << " hambre."<<endl;
	}
}

