#pragma once
#include <string>
#include <iostream>
using namespace std;
class ejemplo1
{
private:
	int num_cabeza;
public:
	int num_patas;
	bool hambre;
	string nombre;
	bool maquina;

	ejemplo1(void);
	ejemplo1(string _nombre,int _patas, int _cabeza, bool _hambre);
	ejemplo1(string _nombre,bool _maquina);
	void set_cabeza(int num_cab);
	int get_cabeza();
	void imprimir();
	~ejemplo1(void);
};

