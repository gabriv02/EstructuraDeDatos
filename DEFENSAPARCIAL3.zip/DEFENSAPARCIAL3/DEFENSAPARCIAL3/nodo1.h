#pragma once
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
using namespace std;


class nodo1
{
	string nombre;
	string direccion;
public:
	nodo1(void);
	~nodo1(void);
	string get_nombre;
	string get_direccion;
	void set_nombre(string nom);
	void set_direccion(string dir);

};

