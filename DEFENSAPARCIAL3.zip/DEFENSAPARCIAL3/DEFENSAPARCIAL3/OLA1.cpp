#include "StdAfx.h"
#include "OLA1.h"


COLA1::COLA1(void)
{
frente=-1;
	final=-1;
}

bool COLA1::vacio(){
	if (frente==final)
	{
		return true;
	}

}

bool COLA1::lleno(){
	if (final==10-1){
		return true;
	}
}

bool COLA1::insertar(nodo1 nodito){
	if (lleno()==true)
	{
		return false;
	}
	else {final++;
	cola[final]=nodito;
	return true;
}
}

bool COLA1::eliminar(nodo1 &nodito){
		if(vacio()==true){
			return false;
		}
		else {frente++;
		nodito=cola[frente];
		return true;
		}
}

int COLA1::get_frente(){
	return frente+1;
}

COLA1::~COLA1()
{

}
