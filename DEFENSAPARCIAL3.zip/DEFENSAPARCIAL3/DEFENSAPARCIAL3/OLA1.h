#pragma once
#include <iostream>
#include "nodo1.h"

class COLA1
{
	nodo1 cola[10];
	int frente;
	int final;
	

public:
	COLA1(void);
	~COLA1(void);
bool vacio();
bool lleno();
bool insertar(nodo1);
bool eliminar(nodo1 &);
int get_frente();

};

