#include "StdAfx.h"

#include "nodo1.h"


nodo1::nodo1(void)
{
	nombre="";
	direccion="";
}

string nodo1::get_nombre(){
	return nombre;
	}


string nodo1::get_direccion(){
	return direccion;
}

void nodo1::set_nombre(string nom){
nombre=nom;
}

void nodo1::set_direccion(string dir){
	direccion=dir;
}

nodo1::~nodo1(void)
{
}
