#include "StdAfx.h"
#include "defensa2.h"


defensa2::defensa2(void)
{
}


defensa2::~defensa2(void)
{
}
void defensa2::iniciar(){
	tope=-1;
	}
int defensa2::gettope(){
	return tope;
}
bool defensa2::pilallena(){
	if(gettope()==tope-1)
		return true;
	else
		return false;
}
bool defensa2::pilavacia(){
	if(gettope()==-1)
		return true;
	else
		return false;
}
bool defensa2::agregar(int dato){
	if(!pilallena()){
		tope=gettope()+1;
		vector[tope]=dato;
		return true;
	}
	if(pilallena()){
		return false;
	}
	}

void defensa2::eliminar(){
	if (!pilavacia())
		tope=gettope()-1;
	}
int defensa2::valortope(){
	return vector[gettope()];
}
