#pragma once
#include <iostream>
using namespace std;

class defensa2
#define MAX 10
{
private:
	int vector[MAX];
	int tope;

public:
	defensa2(void);
	~defensa2(void);
	void iniciar();
	int gettope();
	bool pilallena();
	bool pilavacia();
	bool agregar(int dato);
	void eliminar();
	int valortope();
};

