#pragma once

namespace My0503 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblCuenta;
	protected: 
	private: System::Windows::Forms::Label^  lblIngreso;
	private: System::Windows::Forms::Label^  lblNombre;
	private: System::Windows::Forms::TextBox^  txtNombre;
	private: System::Windows::Forms::TextBox^  txtCuebta;
	private: System::Windows::Forms::TextBox^  txtIngreso;
	private: System::Windows::Forms::Label^  lblSaldo;
	private: System::Windows::Forms::TextBox^  txtSaldo;




	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblCuenta = (gcnew System::Windows::Forms::Label());
			this->lblIngreso = (gcnew System::Windows::Forms::Label());
			this->lblNombre = (gcnew System::Windows::Forms::Label());
			this->txtNombre = (gcnew System::Windows::Forms::TextBox());
			this->txtCuebta = (gcnew System::Windows::Forms::TextBox());
			this->txtIngreso = (gcnew System::Windows::Forms::TextBox());
			this->lblSaldo = (gcnew System::Windows::Forms::Label());
			this->txtSaldo = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// lblCuenta
			// 
			this->lblCuenta->AutoSize = true;
			this->lblCuenta->Location = System::Drawing::Point(17, 77);
			this->lblCuenta->Name = L"lblCuenta";
			this->lblCuenta->Size = System::Drawing::Size(53, 17);
			this->lblCuenta->TabIndex = 0;
			this->lblCuenta->Text = L"Cuenta";
			// 
			// lblIngreso
			// 
			this->lblIngreso->AutoSize = true;
			this->lblIngreso->Location = System::Drawing::Point(17, 120);
			this->lblIngreso->Name = L"lblIngreso";
			this->lblIngreso->Size = System::Drawing::Size(55, 17);
			this->lblIngreso->TabIndex = 1;
			this->lblIngreso->Text = L"Ingreso";
			// 
			// lblNombre
			// 
			this->lblNombre->AutoSize = true;
			this->lblNombre->Location = System::Drawing::Point(14, 27);
			this->lblNombre->Name = L"lblNombre";
			this->lblNombre->Size = System::Drawing::Size(58, 17);
			this->lblNombre->TabIndex = 2;
			this->lblNombre->Text = L"Nombre";
			// 
			// txtNombre
			// 
			this->txtNombre->Location = System::Drawing::Point(146, 27);
			this->txtNombre->Name = L"txtNombre";
			this->txtNombre->Size = System::Drawing::Size(100, 22);
			this->txtNombre->TabIndex = 3;
			// 
			// txtCuebta
			// 
			this->txtCuebta->Location = System::Drawing::Point(146, 72);
			this->txtCuebta->Name = L"txtCuebta";
			this->txtCuebta->Size = System::Drawing::Size(100, 22);
			this->txtCuebta->TabIndex = 4;
			// 
			// txtIngreso
			// 
			this->txtIngreso->Location = System::Drawing::Point(146, 115);
			this->txtIngreso->Name = L"txtIngreso";
			this->txtIngreso->Size = System::Drawing::Size(100, 22);
			this->txtIngreso->TabIndex = 5;
			// 
			// lblSaldo
			// 
			this->lblSaldo->AutoSize = true;
			this->lblSaldo->Location = System::Drawing::Point(17, 164);
			this->lblSaldo->Name = L"lblSaldo";
			this->lblSaldo->Size = System::Drawing::Size(44, 17);
			this->lblSaldo->TabIndex = 6;
			this->lblSaldo->Text = L"Saldo";
			// 
			// txtSaldo
			// 
			this->txtSaldo->Location = System::Drawing::Point(146, 164);
			this->txtSaldo->Name = L"txtSaldo";
			this->txtSaldo->Size = System::Drawing::Size(100, 22);
			this->txtSaldo->TabIndex = 7;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(282, 253);
			this->Controls->Add(this->txtSaldo);
			this->Controls->Add(this->lblSaldo);
			this->Controls->Add(this->txtIngreso);
			this->Controls->Add(this->txtCuebta);
			this->Controls->Add(this->txtNombre);
			this->Controls->Add(this->lblNombre);
			this->Controls->Add(this->lblIngreso);
			this->Controls->Add(this->lblCuenta);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 }
};
}

