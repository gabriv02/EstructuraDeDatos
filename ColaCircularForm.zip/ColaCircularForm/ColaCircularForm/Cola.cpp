#include "StdAfx.h"
#include "Cola.h"
#include <iostream>
#define MAX 10

using namespace std;

Cola::Cola(void)
{ frente=0; //frente de la cola
  n=0; //numero de elementos de la cola
 tamano=0; //tamano o numero maximo de elementos en la cola
 Q[MAX]=0;//cola
}
Cola::~Cola(void)
{
}
int Cola::Get_tamano()
{
	return tamano;
}
void Cola::Set_tamano(int tam)
{
	tamano=tam;
}
int Cola::Get_vector(int posicion)
{
	return Q[posicion];
}
void Cola::Set_vector(int posicion, int elem)
{
	Q[posicion]=elem;
}
int Cola::Get_frente()
{
	return frente;
}
void Cola::Set_frente(int frent)
{
	frente=frent;
}
int Cola::Get_numero()
{
	return n;
}
void Cola::Set_numero(int num)
{
	n=num;
}
bool Cola::Vacio_vector()
{
	if (tamano==0) 
		{return true;}
	else 
	{return false;}	
}
bool Cola::Lleno_vector()
{ 
	if (n==tamano) 
	    {return true;}

	else {return false;}
}
bool Cola::Insertar(int elem, int posicion, int num)
{
	if((num<0)&&(num>Get_tamano()))
	    {return false;}
	else
		{
		if(Lleno_vector()==true) 
			{return false;
		    }
		else
			{if(Q[posicion]==0)
		{Q[posicion]=elem;
		return true;
		}
			else
			{
			    int i=Get_tamano();
				while(i>posicion)
				{
				 Q[i]=Q[i-1];
				 i--;
				}
				Q[posicion]=elem;
				return true;
			}
		}
	}
}
bool Cola::Eliminar(int elem,int pos)
{	int i=0;
	if(Vacio_vector()==true) 
			{return false;}
	else
		{
		 Q[pos]=0;
				return true;
			}
}

