#pragma once
#define MAX 10
class Cola
{private:
 int frente; //frente de la cola
 int n; //numero de elementos de la cola
 int tamano; //tamano o numero maximo de elementos en la cola
 int Q[MAX];//cola
public:
	Cola(void);
	~Cola(void);
	int Get_tamano();
	void Set_tamano(int tam);
	int Get_vector(int posicion);
	void Set_vector(int posicion, int elem); 
	int Get_frente();
	void Set_frente(int frent);
	int Get_numero();
	void Set_numero(int num);
	bool Vacio_vector();
	bool Lleno_vector();
	bool Insertar(int elem, int posicion,int num);
	bool Eliminar(int elem,int pos);

};

