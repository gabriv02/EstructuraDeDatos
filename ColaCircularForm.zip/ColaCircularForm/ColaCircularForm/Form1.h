#pragma once
#include "Cola.h"
#include <iostream>
#include <msclr\marshal_cppstd.h>
#define MAX
namespace ColaCircularForm {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
    using namespace msclr::interop;
	Cola circular; //objeto
	int pos=0;
	int num=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblTamano;
	protected: 
	private: System::Windows::Forms::Label^  lblDato;
	private: System::Windows::Forms::TextBox^  txtTamano;
	private: System::Windows::Forms::TextBox^  txtDato;
	private: System::Windows::Forms::Button^  btnDefinir;
	private: System::Windows::Forms::Button^  btnIngresar;
	private: System::Windows::Forms::Button^  btnEliminar;
	private: System::Windows::Forms::DataGridView^  grillaCola;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblTamano = (gcnew System::Windows::Forms::Label());
			this->lblDato = (gcnew System::Windows::Forms::Label());
			this->txtTamano = (gcnew System::Windows::Forms::TextBox());
			this->txtDato = (gcnew System::Windows::Forms::TextBox());
			this->btnDefinir = (gcnew System::Windows::Forms::Button());
			this->btnIngresar = (gcnew System::Windows::Forms::Button());
			this->btnEliminar = (gcnew System::Windows::Forms::Button());
			this->grillaCola = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillaCola))->BeginInit();
			this->SuspendLayout();
			// 
			// lblTamano
			// 
			this->lblTamano->AutoSize = true;
			this->lblTamano->Location = System::Drawing::Point(12, 29);
			this->lblTamano->Name = L"lblTamano";
			this->lblTamano->Size = System::Drawing::Size(67, 20);
			this->lblTamano->TabIndex = 0;
			this->lblTamano->Text = L"Tamano";
			// 
			// lblDato
			// 
			this->lblDato->AutoSize = true;
			this->lblDato->Location = System::Drawing::Point(12, 83);
			this->lblDato->Name = L"lblDato";
			this->lblDato->Size = System::Drawing::Size(44, 20);
			this->lblDato->TabIndex = 1;
			this->lblDato->Text = L"Dato";
			// 
			// txtTamano
			// 
			this->txtTamano->Location = System::Drawing::Point(113, 29);
			this->txtTamano->Name = L"txtTamano";
			this->txtTamano->Size = System::Drawing::Size(160, 26);
			this->txtTamano->TabIndex = 2;
			// 
			// txtDato
			// 
			this->txtDato->Location = System::Drawing::Point(114, 83);
			this->txtDato->Name = L"txtDato";
			this->txtDato->Size = System::Drawing::Size(158, 26);
			this->txtDato->TabIndex = 3;
			// 
			// btnDefinir
			// 
			this->btnDefinir->Location = System::Drawing::Point(301, 29);
			this->btnDefinir->Name = L"btnDefinir";
			this->btnDefinir->Size = System::Drawing::Size(134, 35);
			this->btnDefinir->TabIndex = 4;
			this->btnDefinir->Text = L"Definir";
			this->btnDefinir->UseVisualStyleBackColor = true;
			this->btnDefinir->Click += gcnew System::EventHandler(this, &Form1::btnDefinir_Click);
			// 
			// btnIngresar
			// 
			this->btnIngresar->Location = System::Drawing::Point(301, 85);
			this->btnIngresar->Name = L"btnIngresar";
			this->btnIngresar->Size = System::Drawing::Size(133, 36);
			this->btnIngresar->TabIndex = 5;
			this->btnIngresar->Text = L"Ingresar";
			this->btnIngresar->UseVisualStyleBackColor = true;
			this->btnIngresar->Click += gcnew System::EventHandler(this, &Form1::btnIngresar_Click);
			// 
			// btnEliminar
			// 
			this->btnEliminar->Location = System::Drawing::Point(451, 85);
			this->btnEliminar->Name = L"btnEliminar";
			this->btnEliminar->Size = System::Drawing::Size(145, 35);
			this->btnEliminar->TabIndex = 6;
			this->btnEliminar->Text = L"Eliminar";
			this->btnEliminar->UseVisualStyleBackColor = true;
			this->btnEliminar->Click += gcnew System::EventHandler(this, &Form1::btnEliminar_Click);
			// 
			// grillaCola
			// 
			this->grillaCola->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grillaCola->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grillaCola->Location = System::Drawing::Point(16, 152);
			this->grillaCola->Name = L"grillaCola";
			this->grillaCola->RowTemplate->Height = 28;
			this->grillaCola->Size = System::Drawing::Size(402, 181);
			this->grillaCola->TabIndex = 7;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Datos";
			this->Column1->Name = L"Column1";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(659, 354);
			this->Controls->Add(this->grillaCola);
			this->Controls->Add(this->btnEliminar);
			this->Controls->Add(this->btnIngresar);
			this->Controls->Add(this->btnDefinir);
			this->Controls->Add(this->txtDato);
			this->Controls->Add(this->txtTamano);
			this->Controls->Add(this->lblDato);
			this->Controls->Add(this->lblTamano);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grillaCola))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnDefinir_Click(System::Object^  sender, System::EventArgs^  e) {
			 int tam;
			 tam=System::Convert::ToInt32(txtTamano->Text);
			 circular.Set_tamano(tam);
			 grillaCola->RowCount=circular.Get_tamano();
			 pos=0;
			 }
private: System::Void btnIngresar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int elemento;
			 pos=(circular.Get_frente() + circular.Get_numero()) % circular.Get_tamano();
			 elemento=System::Convert::ToInt32(txtDato->Text);
			 if (circular.Insertar(elemento,pos,circular.Get_numero())) {
				 num++;
				 circular.Set_numero(num);
				// Despliegue del Vector
				grillaCola->ColumnCount=1;
				grillaCola->RowCount=circular.Get_tamano();
				int i=0, dato;
				for (i=0;i<circular.Get_tamano();i++)
				{
				dato=circular.Get_vector(i);
				grillaCola->Rows[i]->Cells[0]->Value=System::Convert::ToInt32(dato);
				}
			 }
		 }
private: System::Void btnEliminar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int elemento,fren;
			 elemento=System::Convert::ToInt32(txtDato->Text);
			 pos=(circular.Get_frente()%circular.Get_tamano());
			 if (circular.Eliminar(elemento,pos)) {
				// Despliegue del Vector
				grillaCola->ColumnCount=1;
				if (grillaCola->RowCount==1)
					grillaCola->Rows[0]->Cells[0]->Value="";
				else
				{
					grillaCola->RowCount=circular.Get_tamano();
					int i=0, dato;
					for (i=0;i<circular.Get_tamano();i++)
					{
					dato=circular.Get_vector(i);
					grillaCola->Rows[i]->Cells[0]->Value=System::Convert::ToInt32(dato);
					}
				}
			 }
			 fren=circular.Get_frente()+1;
			 circular.Set_frente(fren);
			 num--;
			 circular.Set_numero(num);
		 }
};
}

