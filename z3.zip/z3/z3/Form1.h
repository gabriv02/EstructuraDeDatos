#pragma once
#include "circulo.h"
#include<iostream>
#include<msclr\marshal_cppstd.h>


namespace z3 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblRadio;
	protected: 
	private: System::Windows::Forms::Label^  lblPerimetro;
	private: System::Windows::Forms::Button^  btnCalcular;

	private: System::Windows::Forms::TextBox^  txtPerimetro;

	private: System::Windows::Forms::TextBox^  txtRadio;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblRadio = (gcnew System::Windows::Forms::Label());
			this->lblPerimetro = (gcnew System::Windows::Forms::Label());
			this->btnCalcular = (gcnew System::Windows::Forms::Button());
			this->txtPerimetro = (gcnew System::Windows::Forms::TextBox());
			this->txtRadio = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// lblRadio
			// 
			this->lblRadio->AutoSize = true;
			this->lblRadio->Location = System::Drawing::Point(12, 24);
			this->lblRadio->Name = L"lblRadio";
			this->lblRadio->Size = System::Drawing::Size(45, 17);
			this->lblRadio->TabIndex = 0;
			this->lblRadio->Text = L"Radio";
			this->lblRadio->Click += gcnew System::EventHandler(this, &Form1::lblRadio_Click);
			// 
			// lblPerimetro
			// 
			this->lblPerimetro->AutoSize = true;
			this->lblPerimetro->Location = System::Drawing::Point(12, 104);
			this->lblPerimetro->Name = L"lblPerimetro";
			this->lblPerimetro->Size = System::Drawing::Size(69, 17);
			this->lblPerimetro->TabIndex = 1;
			this->lblPerimetro->Text = L"Perimetro";
			// 
			// btnCalcular
			// 
			this->btnCalcular->Location = System::Drawing::Point(165, 66);
			this->btnCalcular->Name = L"btnCalcular";
			this->btnCalcular->Size = System::Drawing::Size(75, 23);
			this->btnCalcular->TabIndex = 2;
			this->btnCalcular->Text = L"Calcular";
			this->btnCalcular->UseVisualStyleBackColor = true;
			this->btnCalcular->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// txtPerimetro
			// 
			this->txtPerimetro->Location = System::Drawing::Point(153, 104);
			this->txtPerimetro->Name = L"txtPerimetro";
			this->txtPerimetro->Size = System::Drawing::Size(100, 22);
			this->txtPerimetro->TabIndex = 3;
			this->txtPerimetro->TextChanged += gcnew System::EventHandler(this, &Form1::textBox1_TextChanged);
			// 
			// txtRadio
			// 
			this->txtRadio->Location = System::Drawing::Point(153, 24);
			this->txtRadio->Name = L"txtRadio";
			this->txtRadio->Size = System::Drawing::Size(100, 22);
			this->txtRadio->TabIndex = 4;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(282, 253);
			this->Controls->Add(this->txtRadio);
			this->Controls->Add(this->txtPerimetro);
			this->Controls->Add(this->btnCalcular);
			this->Controls->Add(this->lblPerimetro);
			this->Controls->Add(this->lblRadio);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 }
	private: System::Void textBox1_TextChanged(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			 circulo circulito;
				 circulito.Set_radio(System::Convert::ToInt32(txtRadio->Text));
				 double perimetroT;
				 perimetroT=circulito.calcular();
				 txtPerimetro->Text=System::Convert::ToString(perimetroT);
		 }
private: System::Void lblRadio_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}

