#pragma once
ref class circulo
{
private:
	float radio;
	double perimetro;
public:
	circulo(void);
	float Get_radio();
	void Set_radio(float r);
	double Get_perimetro();
	void Set_perimetro(double p);

	double calcular();
};

