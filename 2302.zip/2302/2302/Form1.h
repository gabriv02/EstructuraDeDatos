#pragma once
#include "venta.h"
#include <iostream>
#include <msclr\marshal_cppstd.h>

namespace My2302 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblCantidad;
	protected: 
	private: System::Windows::Forms::Label^  lblPrecio;
	private: System::Windows::Forms::Button^  btnCalcular;
	private: System::Windows::Forms::TextBox^  txtCantidad;
	private: System::Windows::Forms::TextBox^  txtPrecio;
	private: System::Windows::Forms::TextBox^  txtTotal;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblCantidad = (gcnew System::Windows::Forms::Label());
			this->lblPrecio = (gcnew System::Windows::Forms::Label());
			this->btnCalcular = (gcnew System::Windows::Forms::Button());
			this->txtCantidad = (gcnew System::Windows::Forms::TextBox());
			this->txtPrecio = (gcnew System::Windows::Forms::TextBox());
			this->txtTotal = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// lblCantidad
			// 
			this->lblCantidad->AutoSize = true;
			this->lblCantidad->Location = System::Drawing::Point(12, 31);
			this->lblCantidad->Name = L"lblCantidad";
			this->lblCantidad->Size = System::Drawing::Size(64, 17);
			this->lblCantidad->TabIndex = 0;
			this->lblCantidad->Text = L"Cantidad";
			// 
			// lblPrecio
			// 
			this->lblPrecio->AutoSize = true;
			this->lblPrecio->Location = System::Drawing::Point(12, 91);
			this->lblPrecio->Name = L"lblPrecio";
			this->lblPrecio->Size = System::Drawing::Size(48, 17);
			this->lblPrecio->TabIndex = 1;
			this->lblPrecio->Text = L"Precio";
			// 
			// btnCalcular
			// 
			this->btnCalcular->Location = System::Drawing::Point(91, 135);
			this->btnCalcular->Name = L"btnCalcular";
			this->btnCalcular->Size = System::Drawing::Size(75, 23);
			this->btnCalcular->TabIndex = 2;
			this->btnCalcular->Text = L"Calcular";
			this->btnCalcular->UseVisualStyleBackColor = true;
			this->btnCalcular->Click += gcnew System::EventHandler(this, &Form1::btnCalcular_Click);
			// 
			// txtCantidad
			// 
			this->txtCantidad->Location = System::Drawing::Point(140, 31);
			this->txtCantidad->Name = L"txtCantidad";
			this->txtCantidad->Size = System::Drawing::Size(100, 22);
			this->txtCantidad->TabIndex = 3;
			// 
			// txtPrecio
			// 
			this->txtPrecio->Location = System::Drawing::Point(140, 88);
			this->txtPrecio->Name = L"txtPrecio";
			this->txtPrecio->Size = System::Drawing::Size(100, 22);
			this->txtPrecio->TabIndex = 4;
			// 
			// txtTotal
			// 
			this->txtTotal->Location = System::Drawing::Point(80, 181);
			this->txtTotal->Name = L"txtTotal";
			this->txtTotal->Size = System::Drawing::Size(100, 22);
			this->txtTotal->TabIndex = 5;
			this->txtTotal->TextChanged += gcnew System::EventHandler(this, &Form1::txtTotal_TextChanged);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(282, 253);
			this->Controls->Add(this->txtTotal);
			this->Controls->Add(this->txtPrecio);
			this->Controls->Add(this->txtCantidad);
			this->Controls->Add(this->btnCalcular);
			this->Controls->Add(this->lblPrecio);
			this->Controls->Add(this->lblCantidad);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void txtTotal_TextChanged(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void btnCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
			 venta ventita;
			 ventita.Set_precio(System::Convert::ToInt32(txtPrecio->Text));
			 ventita.Set_cantidad(System::Convert::ToInt32(txtCantidad->Text));
			 float TOTAL;
			 TOTAL=ventita.calcular();
			 txtTotal->Text=System::Convert::ToString(TOTAL);
		 }
};
}

