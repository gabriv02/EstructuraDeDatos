#include "StdAfx.h"
#include "venta.h"


venta::venta(void)
{
}
int venta::Get_cantidad()
{
	return cantidad;
}
float venta::Get_precio()
{
	return precio;
}
float total::Get_total()
{
	return total;
}
void venta::Set_cantidad(int c)
{
	cantidad=c;
}
void venta::Set_precio(float p)
{
	precio=p;
}
void venta::Set_total(float total)
{
	total=t;
}
float venta::calcular()
{
	total=catidad*precio;
	return total;
}

